class ApiConfig {
  static const String baseUrl = 'http://192.168.1.15/api';
}
