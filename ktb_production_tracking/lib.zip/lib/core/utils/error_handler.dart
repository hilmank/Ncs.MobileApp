import 'package:flutter/material.dart';
import '../../features/auth/login_screen.dart';
import 'snackbar_helper.dart';
import '../errors/app_exception.dart';

class ErrorHandler {
  static void handle({
    required BuildContext context,
    required Object error,
    StackTrace? stackTrace,
  }) async {
    if (error is AppException && error.message == "Unauthorized") {
      // Redirect to login and clear session
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
        (route) => false,
      );
    } else {
      showErrorSnackbar(context, error.toString());
    }

    debugPrint('Error: $error');
    if (stackTrace != null) debugPrint('StackTrace: $stackTrace');
  }
}
