import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/api_config.dart';
import '../errors/app_exception.dart';
import '../models/delivery_summary_result.dart';
import '../models/delivery_transaction_result.dart';

class DeliveryService {
  final String _baseUrl = '${ApiConfig.baseUrl}/Delivery';

  Future<List<DeliverySummaryResult>> fetchSummary(String token) async {
    final url = Uri.parse("$_baseUrl/summary");

    final response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> decoded = jsonDecode(response.body);
      final List<dynamic> summaryList = decoded['summary'] ?? [];

      return summaryList
          .map((item) => DeliverySummaryResult.fromJson(item))
          .toList();
    }

    throw Exception('Failed to load delivery summary');
  }

  Future<List<DeliveryTransactionResult>> fetchTransactions(
      String token) async {
    final url = Uri.parse("$_baseUrl/transaction");

    final response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final List<dynamic> decoded = jsonDecode(response.body);
      return decoded
          .map((item) => DeliveryTransactionResult.fromJson(item))
          .toList();
    }

    throw Exception('Failed to load delivery transactions');
  }

  Future<Map<String, dynamic>> updateDeliveryStatus(
      String token, String chassisNo) async {
    final url = Uri.parse("$_baseUrl/update-status?chassisNo=$chassisNo");

    final response = await http.put(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }

    try {
      final decoded = jsonDecode(response.body);
      final message =
          decoded['message'] ?? decoded['title'] ?? response.body.toString();
      throw AppException(message);
    } catch (_) {
      throw AppException(response.body.toString());
    }
  }
}
