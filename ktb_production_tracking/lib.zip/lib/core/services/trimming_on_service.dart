import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/api_config.dart';
import '../errors/app_exception.dart';

class TrimmingOnService {
  final String _baseUrl = '${ApiConfig.baseUrl}/TrimmingOn';

  Future<Map<String, dynamic>> fetchSummary(String token) async {
    final url = Uri.parse("$_baseUrl/summary");

    final response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to load trimming-on summary');
    }
  }

  Future<List<Map<String, dynamic>>> fetchTransactions(String token) async {
    final url = Uri.parse("$_baseUrl/transaction");

    final response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      return List<Map<String, dynamic>>.from(jsonDecode(response.body));
    } else {
      throw Exception('Failed to load trimming-on transactions');
    }
  }

  Future<Map<String, dynamic>> updateStatus(
      String token, String cabinNo) async {
    final url = Uri.parse("$_baseUrl/update-status?cabinNo=$cabinNo");

    final response = await http.put(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }

    try {
      final decoded = jsonDecode(response.body);
      final message =
          decoded['message'] ?? decoded['title'] ?? response.body.toString();
      throw AppException(message);
    } catch (_) {
      throw AppException(response.body.toString());
    }
  }
}
