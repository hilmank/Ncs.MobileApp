import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/services/trimming_on_service.dart';
import '../../core/utils/shared_prefs_helper.dart';
import '../../core/utils/error_handler.dart';
import '../../core/errors/app_exception.dart';
import '../auth/login_screen.dart';

class TrimmingOnDetailScreen extends StatefulWidget {
  final String userName;
  final int shiftNo;
  final String companyName;

  const TrimmingOnDetailScreen({
    super.key,
    required this.userName,
    required this.shiftNo,
    this.companyName = "PT. Krama Yudha Ratu Motor",
  });

  @override
  State<TrimmingOnDetailScreen> createState() => _TrimmingOnDetailScreenState();
}

class _TrimmingOnDetailScreenState extends State<TrimmingOnDetailScreen> {
  final TrimmingOnService _service = TrimmingOnService();
  final TextEditingController shiftController =
      TextEditingController(text: "1");
  final TextEditingController snController = TextEditingController();

  List<Map<String, dynamic>> transactions = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadTransactions();
  }

  Future<void> loadTransactions() async {
    try {
      final token = await SharedPrefsHelper.getToken();
      if (token == null || token.isEmpty) {
        if (mounted) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => const LoginScreen()),
            (route) => false,
          );
        }
        return;
      }

      final data = await _service.fetchTransactions(token);

      setState(() {
        transactions = data
            .asMap()
            .entries
            .map((e) => {
                  "no": e.key + 1,
                  "cabin": e.value["cabinNo"],
                  "qty": e.value["quantity"].toString()
                })
            .toList();
        isLoading = false;
      });
    } catch (e) {
      debugPrint("Failed to load transactions: $e");
      setState(() => isLoading = false);
    }
  }

  Future<void> updateTrimmingOnStatus(String cabinNo) async {
    try {
      final token = await SharedPrefsHelper.getToken();
      if (token == null || token.isEmpty) {
        throw AppException("Unauthorized");
      }

      final result = await _service.updateStatus(token, cabinNo);

      final trimming = result['trimming'];
      if (trimming == null) {
        throw AppException(result['message'] ?? "Unknown error");
      }

      setState(() {
        transactions.insert(0, {
          "no": 1,
          "cabin": trimming["cabinNo"],
          "qty": trimming["quantity"].toString(),
        });

        for (var i = 0; i < transactions.length; i++) {
          transactions[i]["no"] = i + 1;
        }

        snController.clear();
      });
    } catch (e, stackTrace) {
      ErrorHandler.handle(context: context, error: e, stackTrace: stackTrace);
    }
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final dateFormatted = DateFormat('EEEE, d MMMM y', 'id_ID').format(now);
    final timeFormatted = DateFormat.Hms().format(now);

    return Scaffold(
      backgroundColor: const Color(0xFFF9F9F9),
      body: SafeArea(
        child: Column(
          children: [
            // 🔴 Header merah seperti dashboard
            Container(
              color: Colors.red,
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 24,
                    backgroundColor: Colors.white,
                    child: Text(
                      "A",
                      style: TextStyle(
                          color: Colors.red, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "${widget.userName} (Shift: ${widget.shiftNo})",
                        style: const TextStyle(color: Colors.white),
                      ),
                      Text(widget.companyName,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const Spacer(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(dateFormatted,
                          style: const TextStyle(color: Colors.white)),
                      Text(timeFormatted,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold)),
                    ],
                  )
                ],
              ),
            ),

            // 🔽 Konten utama
            Expanded(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 🔁 Title + Back button sejajar
                    Row(
                      children: [
                        const Text("Cabin SN",
                            style: TextStyle(
                                color: Colors.black87,
                                fontWeight: FontWeight.w500)),
                        const Spacer(),
                        IconButton(
                          icon:
                              const Icon(Icons.arrow_back, color: Colors.black),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),

                    // 🔁 Input cabin
                    TextField(
                      controller: snController,
                      onSubmitted: (value) {
                        if (value.trim().isNotEmpty) {
                          updateTrimmingOnStatus(value.trim());
                        }
                      },
                      decoration: InputDecoration(
                        hintText: "Enter",
                        contentPadding:
                            const EdgeInsets.symmetric(horizontal: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // 🔁 List transaksi
                    isLoading
                        ? const Expanded(
                            child: Center(child: CircularProgressIndicator()))
                        : Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Container(
                                  color: const Color(0xFFEDEFF1),
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10, horizontal: 8),
                                  child: Row(
                                    children: const [
                                      Expanded(
                                          flex: 1,
                                          child: Text("#",
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      Expanded(
                                          flex: 3,
                                          child: Text("Cabin/Chasis No.",
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      Expanded(
                                          flex: 2,
                                          child: Text("QTY",
                                              style: TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold))),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Expanded(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Colors.black12),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: ListView.separated(
                                      itemCount: transactions.length,
                                      separatorBuilder: (_, __) =>
                                          const Divider(height: 1),
                                      itemBuilder: (context, index) {
                                        final row = transactions[index];
                                        return Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 10, horizontal: 8),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                  flex: 1,
                                                  child: Text('${row["no"]}')),
                                              Expanded(
                                                  flex: 3,
                                                  child: Text(row["cabin"])),
                                              Expanded(
                                                  flex: 2,
                                                  child: Text(row["qty"])),
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                    const SizedBox(height: 16),

                    // 🔁 Shift info
                    Row(
                      children: [
                        const Text("Shift",
                            style: TextStyle(color: Colors.black87)),
                        const SizedBox(width: 12),
                        SizedBox(
                          width: 60,
                          child: TextField(
                            controller: shiftController,
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              contentPadding:
                                  const EdgeInsets.symmetric(vertical: 8),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text("Day",
                            style: TextStyle(color: Colors.black54)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
